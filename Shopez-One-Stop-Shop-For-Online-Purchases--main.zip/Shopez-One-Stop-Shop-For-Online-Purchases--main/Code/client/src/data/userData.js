const users = [
  {
    username: 'user1',
    password: 'user123',
    role: 'user'
  },
  {
    username: 'admin',
    password: 'admin123',
    role: 'admin'
  }
];

export default users;
